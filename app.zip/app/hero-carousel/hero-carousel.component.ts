import { Component } from '@angular/core';

@Component({
  selector: 'app-hero-carousel',
  templateUrl: './hero-carousel.component.html',
  styleUrl: './hero-carousel.component.css'
})
export class HeroCarouselComponent {
  currentIndex = 0;

  slides = [
    { img: 'assets/event1.avif', alt: 'Event 1' },
    { img: 'assets/event2.avif', alt: 'Event 2' },
    { img: 'assets/event3.jpg', alt: 'Event 3' },
  ];

  // Change slide
  changeSlide(index: number) {
    this.currentIndex = index;
  }

  // Autoplay functionality (optional)
  ngOnInit() {
    setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.slides.length;
    }, 5000); // Change slide every 5 seconds
  }
}
