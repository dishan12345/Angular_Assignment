import { Component } from '@angular/core';

@Component({
  selector: 'app-event-grid',
  templateUrl: './event-grid.component.html',
  styleUrl: './event-grid.component.css'
})
export class EventGridComponent {
  events = [
    {
      image: 'assets/event1.avif',
      title: 'Find your Pride in San Francisco year-round fest',
      date: '2024-10-01T19:00:00',
      location: 'Oakland',
      badge: 'Most popular',
      badgeClass: 'popular-badge',
      price: 57.79
    },
    {
      image: 'assets/event2.avif',
      title: 'Make a Difference: Give back at these events',
      date: '2024-10-01T19:00:00',
      location: 'Oakland',
      badge: 'Best price guaranteed',
      badgeClass: 'best-price-badge',
      price: 57.79
    },
    {
      image: 'assets/event3.jpg',
      title: 'Wear green and GTFO at St. Patrick’s Day Special',
      date: '2024-10-01T19:00:00',
      location: 'Oakland',
      badge: 'Most popular',
      badgeClass: 'popular-badge',
      price: 57.79
    },
    {
      image: 'assets/event4.avif',
      title: 'Women’s History Month',
      date: '2024-10-01T19:00:00',
      location: 'Oakland',
      badge: 'Top selling',
      badgeClass: 'top-selling-badge',
      price: 57.79
    }
  ];
}
